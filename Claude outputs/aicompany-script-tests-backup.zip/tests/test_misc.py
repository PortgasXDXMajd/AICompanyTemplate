import http.server
import json
import shutil
import subprocess
import sys
import threading
import unittest

from harness import CompanyTest


class SkillsTests(CompanyTest):
    tools = ("npx",)

    def test_list_shows_every_pinned_skill_and_flags_a_missing_one(self):
        out = self.ok("skills.py", "list")
        for s in ("grilling", "tdd", "improve", "herdr", "improve-codebase-architecture", "codebase-design", "domain-modeling", "thermo-nuclear-code-quality-review"):
            self.assertRegex(out, rf"(?m)^{s}\s.*present$")
        shutil.rmtree(self.root / ".claude" / "skills" / "tdd")
        self.assertRegex(self.ok("skills.py", "list"), r"(?m)^tdd\s.*MISSING$")

    def test_install_runs_npx_once_per_source_as_project_level_copies(self):
        self.ok("skills.py", "install")
        calls = [c["args"] for c in self.fake_calls("npx")]
        self.assertEqual(len(calls), 4)
        for c in calls:
            self.assertEqual(c[:3], ["--yes", "skills", "add"]); self.assertEqual(c[-4:], ["-a", "claude-code", "--copy", "-y"]); self.assertNotIn("-g", c)
        installed = {s for c in calls for s in c[c.index("--skill") + 1:c.index("-a")]}
        lock = set(json.loads((self.root / "skills-lock.json").read_text())["skills"])
        self.assertEqual(installed, lock, "skills.py must install exactly what skills-lock.json pins")
        self.assertEqual(self.fake_calls("npx")[0]["cwd"], str(self.root))

    def test_update_and_failure(self):
        self.ok("skills.py", "update")
        self.assertEqual(self.fake_calls("npx")[0]["args"][:3], ["--yes", "skills", "update"])
        self.fails("skills.py", "install", env={"FAKE_NPX": "fail"}, needle="npx skills failed")


class QaProbeTests(CompanyTest):
    def test_bare_machine_is_reported_honestly(self):
        d = self.js("qa_probe.py")
        self.assertFalse(d["playwright_mcp"]); self.assertIsNone(d["maestro"]); self.assertIsNone(d["adb"])
        self.assertIn("NOT possible", d["mobile_qa"]); self.assertIn("not performed", d["mobile_qa"]); self.assertIn("Claude in Chrome", d["web_qa"])

    def test_full_toolchain(self):
        for t in ("claude", "maestro", "java", "adb", "emulator"):
            self.fake(t)
        env = {"FAKE_MCP": "playwright: npx @playwright/mcp - connected\nmaestro: maestro mcp - connected", "FAKE_AVDS": "Pixel_8", "FAKE_ACCEL": "ok"}
        d = self.js("qa_probe.py", env=env)
        self.assertTrue(d["playwright_mcp"] and d["maestro_mcp"]); self.assertEqual(d["android_avds"], ["Pixel_8"]); self.assertTrue(d["android_accel_ok"])
        self.assertIn("possible (Maestro", d["mobile_qa"]); self.assertEqual(d["web_qa"], "playwright MCP")

    def test_emulator_without_acceleration_is_never_recommended(self):
        for t in ("adb", "emulator"):
            self.fake(t)
        d = self.js("qa_probe.py", env={"FAKE_AVDS": "Pixel_8", "FAKE_ACCEL": "no"})
        self.assertFalse(d["android_accel_ok"]); self.assertIn("Never boot an unaccelerated emulator", d["mobile_qa"])

    def test_usb_device_without_maestro(self):
        self.fake("adb")
        d = self.js("qa_probe.py", env={"FAKE_ADB_DEVICES": "R58M123"})
        self.assertEqual(d["android_devices"], ["R58M123"]); self.assertIn("raw adb", d["mobile_qa"])

    def test_wait_url_up_404_counts_and_timeout(self):
        class H(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                self.send_response(200 if self.path == "/" else 404); self.end_headers()
            def log_message(self, format, *args): pass
        srv = http.server.HTTPServer(("127.0.0.1", 0), H); port = srv.server_address[1]
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        try:
            self.assertIn("HTTP 200", self.ok("qa_probe.py", "wait-url", f"http://127.0.0.1:{port}/"))
            self.assertIn("HTTP 404", self.ok("qa_probe.py", "wait-url", f"http://127.0.0.1:{port}/missing"))
        finally:
            srv.shutdown(); srv.server_close()
        self.fails("qa_probe.py", "wait-url", f"http://127.0.0.1:{port}/", "--timeout", "3", needle="gave up after 3s")


class PreflightTests(CompanyTest):
    tools = ("claude", "npx", "gh", "herdr")

    def checks(self, env=None):
        code, out, _ = self.run_script("preflight.py", "--json", env=env)
        return code, {c["check"]: c for c in json.loads(out)}

    def test_ready_machine_passes(self):
        code, c = self.checks(env={"HERDR_ENV": "1"})
        self.assertEqual(code, 0)
        for name in ("git", "HQ is a git repo with a first commit", "claude CLI", "gh CLI", "gh authenticated", "herdr", "running inside Herdr", "third-party skills present", "jobs/BOARD.md", ".claude/settings.json"):
            self.assertTrue(c[name]["ok"], name)

    def test_missing_first_commit_is_required_and_comes_with_the_fix(self):
        shutil.rmtree(self.root / ".git")
        code, c = self.checks()
        self.assertEqual(code, 1); self.assertFalse(c["HQ is a git repo with a first commit"]["ok"]); self.assertIn("git commit", c["HQ is a git repo with a first commit"]["fix"])

    def test_missing_skill_missing_gh_login_and_no_herdr_session(self):
        shutil.rmtree(self.root / ".claude" / "skills" / "grilling")
        code, c = self.checks(env={"FAKE_GH_AUTH": "no"})
        self.assertEqual(code, 1); self.assertIn("grilling", c["third-party skills present"]["fix"])
        self.assertFalse(c["gh authenticated"]["ok"]); self.assertEqual(c["gh authenticated"]["level"], "recommended")
        self.assertFalse(c["running inside Herdr"]["ok"]); self.assertEqual(c["running inside Herdr"]["level"], "optional")

    def test_optional_tools_missing_do_not_fail_the_run(self):
        for t in ("gh", "herdr", "npx"):
            (self.bin / t).unlink()
        code, c = self.checks()
        self.assertEqual(code, 0); self.assertFalse(c["gh CLI"]["ok"]); self.assertNotIn("gh authenticated", c)
        self.assertIn("[warn] gh CLI", self.run_script("preflight.py")[1])


class DoctorTests(CompanyTest):
    def problems(self, *args):
        code, out, _ = self.run_script("doctor.py", *args)
        return code, out

    def test_the_shipped_template_is_clean(self):
        code, out = self.problems()
        self.assertEqual(code, 0, out); self.assertIn("no problems found", out); self.assertRegex(out, r"CLAUDE\.md: \d+ words \(budget 1800\)")

    def test_unfinished_hire_is_flagged_and_a_finished_one_is_not(self):
        self.ok("team.py", "add", "backend-engineer", "--owns", "x", "--developer")
        code, out = self.problems()
        self.assertEqual(code, 1); self.assertIn("unfilled placeholders", out); self.assertIn("routing rule", out)
        role = self.root / ".claude" / "agents" / "backend-engineer.md"
        import re
        role.write_text(re.sub(r"<FILL:[^<>\n]*>", "filled", role.read_text()))
        self.assertEqual(self.problems()[0], 0)
        self.ok("team.py", "add-adviser")
        self.assertEqual(self.problems()[0], 0, "the adviser's <project>-style text is not a placeholder")

    def test_isolation_field_skill_name_mismatch_and_broken_settings(self):
        self.ok("team.py", "add-adviser")
        role = self.root / ".claude" / "agents" / "senior-technical-adviser.md"
        role.write_text(role.read_text().replace("memory: project", "memory: project\nisolation: worktree", 1))
        skill = self.root / ".claude" / "skills" / "delegate" / "SKILL.md"
        skill.write_text(skill.read_text().replace("name: delegate", "name: delegation", 1))
        (self.root / ".claude" / "settings.json").write_text("{ not json")
        code, out = self.problems()
        self.assertEqual(code, 1)
        for needle in ("remove `isolation`", "skill delegate: frontmatter name is 'delegation'", "settings.json"):
            self.assertIn(needle, out)

    def test_push_gate_missing_and_vendored_skill_missing(self):
        s = self.root / ".claude" / "settings.json"
        d = json.loads(s.read_text()); d["permissions"]["ask"] = [r for r in d["permissions"]["ask"] if "push" not in r]; s.write_text(json.dumps(d))
        shutil.rmtree(self.root / ".claude" / "skills" / "herdr")
        _, out = self.problems()
        self.assertIn("no `ask` rule for git push", out); self.assertIn("third-party skill herdr", out)

    def test_budgets_and_refs_subcommands(self):
        c = self.root / "CLAUDE.md"; c.write_text(c.read_text() + "\n" + "word " * 2000 + "\nSee `context/vanished.md` and `scripts/job.py`.\n")
        code, out = self.problems("budgets"); self.assertEqual(code, 1); self.assertIn("over budget", out); self.assertNotIn("vanished", out)
        code, out = self.problems("refs"); self.assertEqual(code, 1); self.assertIn("`context/vanished.md`", out); self.assertNotIn("job.py", out.split("problem(s):")[1])
        self.make_project("my-app")
        (self.root / "projects" / "my-app" / "CLAUDE.md").write_text("word " * 900)
        self.assertIn("projects/my-app/CLAUDE.md is over budget", self.problems("budgets")[1])

    def test_board_and_job_folder_mismatches(self):
        job = self.new_job(); shutil.rmtree(self.root / "jobs" / job)
        (self.root / "jobs" / "20250101-ghost--x").mkdir()
        board = self.root / "jobs" / "BOARD.md"
        board.write_text(board.read_text().replace("| briefed |", "| finished |"))
        _, out = self.problems()
        for needle in ("unknown state 'finished'", "has no job folder", "jobs/20250101-ghost--x: not on the board and not closed"):
            self.assertIn(needle, out)

    def test_doctor_changes_nothing(self):
        before = self.git(self.root, "status", "--short")
        self.problems()
        self.assertEqual(before, self.git(self.root, "status", "--short"))


class LibTests(CompanyTest):
    def py(self, code):
        p = subprocess.run([sys.executable, "-c", "import sys; sys.path.insert(0, 'scripts'); import _lib as L\n" + code],
                           cwd=str(self.root), env=self.env, text=True, capture_output=True)
        self.assertEqual(p.returncode, 0, p.stderr); return p.stdout.strip()

    def test_verdict_line_variants(self):
        d = self.root / "v"; d.mkdir()
        cases = {"a.md": ("x\nVerdict: pass\n", "pass"), "b.md": ("**Verdict:** pass with fixes\n\n", "pass with fixes"),
                 "c.md": ("Verdict: skipped: no user-facing surface", "skipped: no user-facing surface"),
                 "d.md": ("Verdict: fail\nmore text\nVerdict: pass", "pass"), "e.md": ("the verdict is unclear\n", "None")}
        for name, (text, want) in cases.items():
            (d / name).write_text(text)
            self.assertEqual(self.py(f"print(L.verdict_of('v/{name}'))"), want, name)
        self.assertEqual(self.py("print(L.verdict_of('v/missing.md'))"), "None")

    def test_root_resolution_and_cell_cleaning(self):
        self.assertEqual(self.py("print(L.ROOT)"), str(self.root.resolve()))
        self.assertEqual(self.py(r"print(L.clean_cell('a | b\n  c'))"), "a / b c")

    def test_states_in_lib_match_the_documented_states(self):
        states = self.py("print(','.join(L.STATES))").split(",")
        readme = (self.root / "jobs" / "README.md").read_text()
        for s in states:
            self.assertIn(f"| `{s}` |", readme)

    def test_every_script_has_help_and_compiles(self):
        for s in sorted((self.root / "scripts").glob("*.py")):
            if s.name.startswith("_"):
                continue
            code, out, err = self.run_script(s.name, "--help")
            self.assertEqual(code, 0, f"{s.name} --help: {err}"); self.assertIn("usage:", out.lower())

    def test_every_script_invocation_in_the_docs_uses_a_real_script_and_real_flags(self):
        import re
        vendored = set(json.loads((self.root / "skills-lock.json").read_text())["skills"])
        helps = {}
        def help_text(script, sub=None):
            key = (script, sub)
            if key not in helps:
                helps[key] = self.run_script(script, *( [sub] if sub else [] ), "--help")[1]
            return helps[key]
        checked = 0
        for md in list(self.root.rglob("*.md")):
            rel = md.relative_to(self.root).parts
            if rel[0] in ("worktrees", "projects", "tests") or (rel[:2] == (".claude", "skills") and rel[2] in vendored):
                continue
            for m in re.finditer(r"python3 scripts/(\w+\.py)([^\n`#]*)", md.read_text()):
                script, rest = m.group(1), m.group(2)
                self.assertTrue((self.root / "scripts" / script).exists(), f"{md}: {script} does not exist")
                top = help_text(script)
                subs = re.search(r"\{([a-z,\-]+)\}", top)
                toks = rest.split()
                sub = next((t for t in toks if subs and t in subs.group(1).split(",")), None)
                for flag in re.findall(r"(?<![\w-])(--[a-z][a-z-]+)", rest):
                    where = top + (help_text(script, sub) if sub else "")
                    self.assertIn(flag, where, f"{'/'.join(rel)}: `{m.group(0).strip()}` uses unknown flag {flag}")
                    checked += 1
                if "--json" in toks and sub:
                    self.assertLess(toks.index("--json"), toks.index(sub), f"{'/'.join(rel)}: --json must come before the subcommand: {m.group(0)}")
        self.assertGreater(checked, 40)


if __name__ == "__main__":
    unittest.main()

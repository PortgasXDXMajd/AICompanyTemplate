# tests/

Automated tests for everything in `scripts/`. Standard library only (`unittest`), no installs.

```bash
python3 -m unittest discover -s tests            # everything, about 20 seconds
python3 -m unittest discover -s tests -v         # with test names
cd tests && python3 -m unittest test_worktree    # one file
```

**They never touch this repo.** Every test copies the template into a temp folder, gives it its own git repo, its own git identity and its own `PATH`, runs the copied scripts there, and deletes the folder. Your jobs, journal, worktrees and git config are not read or written.

External tools are faked (`harness.py`): `herdr`, `gh`, `npx`, `claude`, `maestro`, `java`, `adb`, `emulator`. The fakes record how they were called, so the tests can check the exact Herdr and npx commands the scripts issue, and they can be told to misbehave (agent not ready, prompt stalled, agent blocked, clone fails, no hardware acceleration). `git` is real.

| File | Covers |
|---|---|
| `test_job_journal.py` | `job.py` (new, set, progress, show, list, close, table safety), `journal.py`, and that a script copy inside an HQ worktree still writes to the real HQ root |
| `test_worktree.py` | `worktree.py`: naming, base, parallel worktrees, every refusal, pull and diverged remote, the CEO merge gate, behind branches and `update`, conflict abort, remove safety nets, stray detection |
| `test_agent.py` | `agent.py` against a fake Herdr: exact commands, unique names, helpers never take the Runner column, exit codes for not-ready, stalled and blocked, fix-round prompts |
| `test_status.py` | `status.py`: every verdict (never started, possibly running, interrupted, finished not reviewed, review unfinished, fix round cut off, merged not closed, needs the CEO, live runner and helpers), strays and orphans |
| `test_project_team.py` | `project.py`, `team.py`, and a guard that no script ever runs `git push`, `gh repo create` or `gh pr merge` |
| `test_misc.py` | `skills.py`, `qa_probe.py`, `preflight.py`, `doctor.py`, `_lib.py`, `--help` of every script, and that every `python3 scripts/...` line in the skills and docs uses a real script and real flags |

What the tests cannot tell you: whether a real Herdr answers the way the fake does (in particular the shape of `herdr agent list`), and whether Claude Code follows the skills. The first live run is still the first live run.

Run the suite after changing any script, skill command line, `jobs/README.md` state, or the employee template. A change to a script comes with a change to its tests, test first.

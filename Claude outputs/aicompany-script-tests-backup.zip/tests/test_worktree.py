import shutil
import unittest

from harness import CompanyTest


class WorktreeTests(CompanyTest):
    def setUp(self):
        super().setUp()
        self.proj = self.make_project("my-app")

    # ------------------------------------------------------------------ add
    def test_add_product_worktree_names_branch_base_and_fills_board_and_brief(self):
        job = self.new_job()
        head = self.git(self.proj, "rev-parse", "HEAD")
        wt, d = self.add_worktree(job)
        self.assertEqual(d["worktree"], "worktrees/my-app/backend-engineer--003-email-signup")
        self.assertEqual(d["branch"], "backend-engineer/003-email-signup")
        self.assertTrue(head.startswith(d["base"])); self.assertEqual(d["cut_from"], "main")
        self.assertTrue((wt / "app.py").exists(), "the worktree is a checkout of the product repo")
        self.assertEqual(self.git(wt, "symbolic-ref", "--short", "HEAD"), "backend-engineer/003-email-signup")
        r = self.row(job)
        self.assertEqual((r["Worktree"], r["Branch"], r["Base"]), (d["worktree"], d["branch"], d["base"]))
        brief = (self.root / "jobs" / job / "brief.md").read_text()
        self.assertIn(str(wt), brief); self.assertIn(d["base"], brief); self.assertNotIn("filled in by worktree.py", brief)
        self.assertEqual(self.git(self.root, "status", "--short", "--", "worktrees"), "", "worktrees/ must stay gitignored in HQ")

    def test_add_hq_worktree_contains_hq_files_but_no_product_code(self):
        job = self.new_job("growth-marketer", "landing-copy", "_hq")
        wt, d = self.add_worktree(job, "growth-marketer", "landing-copy", "_hq")
        self.assertEqual(d["worktree"], "worktrees/_hq/growth-marketer--landing-copy")
        self.assertTrue((wt / "CLAUDE.md").exists()); self.assertTrue((wt / ".claude" / "skills").is_dir())
        self.assertFalse((wt / "projects" / "my-app").exists())

    def test_two_employees_can_work_on_the_same_project_in_parallel(self):
        w1, _ = self.add_worktree(self.new_job())
        w2, _ = self.add_worktree(self.new_job("frontend-engineer", "004-ui"), "frontend-engineer", "004-ui")
        self.commit_in(w1, "api.py"); self.commit_in(w2, "ui.py")
        self.assertFalse((w2 / "api.py").exists()); self.assertFalse((w1 / "ui.py").exists())
        self.assertEqual(self.git(self.proj, "status", "--short"), "", "the main checkout is untouched")

    def test_add_refusals(self):
        job = self.new_job(); self.add_worktree(job)
        self.fails("worktree.py", "add", "--repo", "my-app", "--employee", "backend-engineer", "--slug", "003-email-signup", needle="already exists")
        self.fails("worktree.py", "add", "--repo", "nope", "--employee", "dev", "--slug", "x", needle="no product repo")
        self.fails("worktree.py", "add", "--repo", "my-app", "--employee", "Dev", "--slug", "x", needle="kebab-case")
        (self.proj / "dirty.txt").write_text("x")
        self.fails("worktree.py", "add", "--repo", "my-app", "--employee", "dev", "--slug", "y", needle="not clean")

    def test_add_existing_reopens_a_kept_branch_and_plain_add_refuses_it(self):
        wt, _ = self.add_worktree(self.new_job()); self.commit_in(wt)
        self.ok("worktree.py", "remove", wt, "--keep-branch")
        self.fails("worktree.py", "add", "--repo", "my-app", "--employee", "backend-engineer", "--slug", "003-email-signup", needle="--existing")
        d = self.js("worktree.py", "add", "--repo", "my-app", "--employee", "backend-engineer", "--slug", "003-email-signup", "--existing")
        self.assertTrue((self.root / d["worktree"] / "feature.py").exists(), "the kept commits are back")

    def test_add_pulls_fast_forward_and_stops_when_it_cannot(self):
        remote = self.tmp / "remote.git"
        self.git(self.tmp, "clone", "-q", "--bare", str(self.proj), str(remote))
        self.git(self.proj, "remote", "add", "origin", str(remote)); self.git(self.proj, "fetch", "-q", "origin")
        self.git(self.proj, "branch", "--set-upstream-to=origin/main", "main")
        other = self.tmp / "other"; self.git(self.tmp, "clone", "-q", str(remote), str(other))
        (other / "remote.txt").write_text("from remote\n"); self.git(other, "add", "-A"); self.git(other, "commit", "-qm", "remote work"); self.git(other, "push", "-q")
        wt, _ = self.add_worktree(self.new_job())
        self.assertTrue((wt / "remote.txt").exists(), "add pulls before cutting the worktree")
        # now diverge: local main has a commit the remote lacks, and the remote moved on
        (self.proj / "local.txt").write_text("x"); self.git(self.proj, "add", "-A"); self.git(self.proj, "commit", "-qm", "local")
        (other / "r2.txt").write_text("y"); self.git(other, "add", "-A"); self.git(other, "commit", "-qm", "r2"); self.git(other, "push", "-q")
        self.fails("worktree.py", "add", "--repo", "my-app", "--employee", "dev", "--slug", "z", needle="never reset or rebase")

    # --------------------------------------------------------------- status
    def test_status_reports_uncommitted_commits_and_diffstat(self):
        wt, d = self.add_worktree(self.new_job())
        self.commit_in(wt); (wt / "junk.txt").write_text("x")
        s = self.js("worktree.py", "status", wt, "--base", d["base"])
        self.assertEqual(s["uncommitted"], ["?? junk.txt"]); self.assertEqual(len(s["commits_since_base"]), 1)
        self.assertEqual((s["ahead_of_default"], s["behind_default"], s["merged_into_default"]), (1, 0, False))
        self.assertIn("1 file changed", s["diffstat"])
        self.fails("worktree.py", "status", self.root / "jobs", needle="not under worktrees")

    # ---------------------------------------------------------------- merge
    def test_merge_into_product_needs_the_ceo_flag(self):
        wt, _ = self.add_worktree(self.new_job()); self.commit_in(wt)
        self.fails("worktree.py", "merge", wt, "--title", "signup", needle="CEO")
        self.assertFalse((self.proj / "feature.py").exists())
        d = self.js("worktree.py", "merge", wt, "--title", "signup", "--approved-by-ceo")
        self.assertTrue((self.proj / "feature.py").exists()); self.assertEqual(d["into"], "my-app:main")
        self.assertIn("Merge backend-engineer/003-email-signup: signup", self.git(self.proj, "log", "-1", "--format=%s"))
        self.assertIn("merged backend-engineer/003-email-signup", self.journal())

    def test_merge_refuses_uncommitted_work_and_empty_branches(self):
        wt, _ = self.add_worktree(self.new_job())
        self.fails("worktree.py", "merge", wt, "--title", "t", "--approved-by-ceo", needle="never committed")
        (wt / "plan.md").write_text("uncommitted plan\n")
        self.fails("worktree.py", "merge", wt, "--title", "t", "--approved-by-ceo", needle="uncommitted files")

    def test_merge_refuses_when_the_product_main_checkout_is_dirty(self):
        wt, _ = self.add_worktree(self.new_job()); self.commit_in(wt)
        (self.proj / "stray.txt").write_text("x")
        self.fails("worktree.py", "merge", wt, "--title", "t", "--approved-by-ceo", needle="not clean")

    def test_behind_branch_is_sent_back_then_update_gives_a_new_base(self):
        w1, _ = self.add_worktree(self.new_job())
        w2, d2 = self.add_worktree(self.new_job("frontend-engineer", "004-ui"), "frontend-engineer", "004-ui")
        self.commit_in(w1, "api.py"); self.commit_in(w2, "ui.py")
        self.ok("worktree.py", "merge", w1, "--title", "api", "--approved-by-ceo")
        self.fails("worktree.py", "merge", w2, "--title", "ui", "--approved-by-ceo", needle="behind")
        u = self.js("worktree.py", "update", w2)
        self.assertNotEqual(u["new_base"], d2["base"]); self.assertTrue((w2 / "api.py").exists())
        self.ok("worktree.py", "merge", w2, "--title", "ui", "--approved-by-ceo")
        self.assertTrue((self.proj / "ui.py").exists() and (self.proj / "api.py").exists())

    def test_conflict_is_aborted_and_the_main_checkout_stays_clean(self):
        w1, _ = self.add_worktree(self.new_job())
        w2, _ = self.add_worktree(self.new_job("frontend-engineer", "004-ui"), "frontend-engineer", "004-ui")
        self.commit_in(w1, "app.py", "def signup():\n    return 'backend'\n"); self.commit_in(w2, "app.py", "def signup():\n    return 'frontend'\n")
        self.ok("worktree.py", "merge", w1, "--title", "a", "--approved-by-ceo")
        self.fails("worktree.py", "merge", w2, "--title", "b", "--approved-by-ceo", "--allow-behind", needle="aborted")
        self.assertEqual(self.git(self.proj, "status", "--short"), "")
        self.assertIn("backend", (self.proj / "app.py").read_text())
        out = self.fails("worktree.py", "update", w2, code=2, needle="CONFLICT")
        self.assertIn("app.py", out)
        (w2 / "app.py").write_text("def signup():\n    return 'both'\n"); self.git(w2, "add", "app.py"); self.git(w2, "commit", "-q", "--no-edit")
        self.ok("worktree.py", "merge", w2, "--title", "b", "--approved-by-ceo")
        self.assertIn("both", (self.proj / "app.py").read_text())

    def test_update_refuses_a_dirty_worktree(self):
        wt, _ = self.add_worktree(self.new_job()); (wt / "x.txt").write_text("x")
        self.fails("worktree.py", "update", wt, needle="commit or clean up first")

    def test_hq_merge_needs_no_ceo_flag_and_tolerates_a_moving_hq_main(self):
        job = self.new_job("senior-technical-adviser", "spec-001", "_hq")
        wt, _ = self.add_worktree(job, "senior-technical-adviser", "spec-001", "_hq")
        (wt / "plans" / "my-app").mkdir(parents=True); (wt / "plans" / "my-app" / "001-scaffold.md").write_text("# Plan 001\n")
        self.git(wt, "add", "plans"); self.git(wt, "commit", "-qm", "Plans: spec-001")
        self.git(self.root, "add", "-A"); self.git(self.root, "commit", "-qm", "journal and jobs moved on")   # HQ main is now ahead
        self.ok("journal.py", "add", "and HQ main is dirty too")                                              # and dirty
        self.ok("worktree.py", "merge", wt, "--title", "plans for spec 001")
        self.assertTrue((self.root / "plans" / "my-app" / "001-scaffold.md").exists())

    # --------------------------------------------------------------- remove
    def test_remove_after_merge_deletes_worktree_and_branch(self):
        wt, _ = self.add_worktree(self.new_job()); self.commit_in(wt)
        self.ok("worktree.py", "merge", wt, "--title", "t", "--approved-by-ceo")
        d = self.js("worktree.py", "remove", wt)
        self.assertTrue(d["branch_deleted"]); self.assertFalse(wt.exists())
        self.assertEqual(self.git(self.proj, "branch", "--list", "backend-engineer/*"), "")

    def test_remove_never_loses_unmerged_or_uncommitted_work(self):
        wt, _ = self.add_worktree(self.new_job()); self.commit_in(wt)
        (wt / "leftover.txt").write_text("x")
        self.fails("worktree.py", "remove", wt, needle="refused")
        self.assertTrue(wt.exists())
        (wt / "leftover.txt").unlink()
        d = self.js("worktree.py", "remove", wt)
        self.assertFalse(d["branch_deleted"]); self.assertIn("not merged", d["note"])
        self.assertIn("backend-engineer/003-email-signup", self.git(self.proj, "branch", "--list", "backend-engineer/*"))

    def test_remove_keep_branch(self):
        wt, _ = self.add_worktree(self.new_job()); self.commit_in(wt)
        d = self.js("worktree.py", "remove", wt, "--keep-branch")
        self.assertTrue(d["branch_kept"]); self.assertFalse(wt.exists())

    # ----------------------------------------------------------------- list
    def test_list_links_worktrees_to_jobs_and_finds_strays_and_missing_ones(self):
        self.assertIn("no worktrees", self.ok("worktree.py", "list"))
        job = self.new_job(); wt, _ = self.add_worktree(job)
        self.ok("worktree.py", "add", "--repo", "my-app", "--employee", "dev", "--slug", "stray")   # no --job
        d = self.js("worktree.py", "list")
        by = {w["worktree"]: w["job"] for w in d["worktrees"]}
        self.assertEqual(by["worktrees/my-app/backend-engineer--003-email-signup"], job)
        self.assertTrue(by["worktrees/my-app/dev--stray"].startswith("NONE"))
        self.git(self.proj, "worktree", "remove", "--force", str(wt))
        d = self.js("worktree.py", "list")
        self.assertTrue(any(job in p for p in d["problems"]))

    def test_add_refuses_before_hq_has_a_first_commit(self):
        shutil.rmtree(self.root / ".git")
        self.git(self.root, "init", "-q", "-b", "main")
        self.fails("worktree.py", "add", "--repo", "_hq", "--employee", "dev", "--slug", "x", needle="first commit")


if __name__ == "__main__":
    unittest.main()

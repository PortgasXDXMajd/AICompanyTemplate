import json
import os
import time
import unittest

from harness import CompanyTest


class StatusTests(CompanyTest):
    tools = ()

    def setUp(self):
        super().setUp()
        self.proj = self.make_project("my-app")

    def status(self, env=None):
        d = self.js("status.py", env=env)
        return d, {j["job"]: j for j in d["open_jobs"]}

    def age(self, job, minutes):
        p = self.root / "jobs" / job / "progress.md"
        t = time.time() - minutes * 60
        os.utime(p, (t, t))

    def test_empty_company(self):
        d, jobs = self.status()
        self.assertEqual(jobs, {}); self.assertEqual(d["stray_worktrees"], []); self.assertIn("plain terminal", d["where"])
        self.assertIn("Open jobs: 0", self.ok("status.py"))

    def test_never_started(self):
        job = self.new_job()
        _, jobs = self.status()
        self.assertTrue(jobs[job]["suggested"].startswith("NEVER STARTED"))
        self.ok("job.py", "set", job, "--state", "running", "--runner", "subagent")     # crash right after the board write
        _, jobs = self.status()
        self.assertTrue(jobs[job]["suggested"].startswith("NEVER STARTED"))

    def test_interrupted_versus_possibly_still_running(self):
        job = self.new_job(); wt, _ = self.add_worktree(job)
        self.ok("job.py", "set", job, "--state", "running", "--runner", "subagent")
        self.ok("job.py", "progress", job, "start: step 2"); self.commit_in(wt)
        _, jobs = self.status()
        self.assertTrue(jobs[job]["suggested"].startswith("POSSIBLY STILL RUNNING"), jobs[job]["suggested"])
        self.age(job, 45)
        _, jobs = self.status()
        f = jobs[job]
        self.assertTrue(f["suggested"].startswith("INTERRUPTED"), f["suggested"])
        self.assertEqual(len(f["commits"]), 1); self.assertFalse(f["runner_alive"]); self.assertEqual(f["minutes_since_progress"] // 5, 9)

    def test_direct_session_is_never_called_interrupted_without_asking(self):
        job = self.new_job()
        self.ok("job.py", "set", job, "--state", "running", "--runner", "direct session"); self.ok("job.py", "progress", job, "x"); self.age(job, 300)
        _, jobs = self.status()
        self.assertTrue(jobs[job]["suggested"].startswith("POSSIBLY STILL RUNNING"))

    def test_finished_not_reviewed_then_review_unfinished_then_in_progress(self):
        job = self.new_job(); d = self.root / "jobs" / job
        self.ok("job.py", "progress", job, "done"); self.age(job, 60)
        (d / "handback.md").write_text("# Hand-back\n")
        _, jobs = self.status(); self.assertTrue(jobs[job]["suggested"].startswith("FINISHED, NOT REVIEWED"))
        (d / "review-brief.md").write_text("brief\n"); (d / "review.md").write_text("# Review\ncut off mid-sent")
        _, jobs = self.status()
        self.assertTrue(jobs[job]["suggested"].startswith("REVIEW UNFINISHED"), jobs[job]["suggested"]); self.assertNotIn("review-brief.md", jobs[job]["verdicts"])
        (d / "review.md").write_text("# Review\n\n**Verdict:** pass with fixes\n")
        _, jobs = self.status()
        self.assertEqual(jobs[job]["verdicts"]["review.md"], "pass with fixes")
        self.assertTrue(jobs[job]["suggested"].startswith("REVIEW IN PROGRESS OR DONE"))

    def test_fix_round_cut_off(self):
        job = self.new_job(); d = self.root / "jobs" / job
        (d / "handback.md").write_text("h\n"); (d / "review.md").write_text("Verdict: pass with fixes\n"); (d / "fix-1-brief.md").write_text("fix\n")
        _, jobs = self.status(); self.assertTrue(jobs[job]["suggested"].startswith("FIX ROUND CUT OFF (fix-1-brief.md)"))
        (d / "fix-1-handback.md").write_text("done\n")
        _, jobs = self.status(); self.assertFalse(jobs[job]["suggested"].startswith("FIX ROUND"))

    def test_merged_but_not_closed_is_detected_so_the_ceo_is_not_asked_twice(self):
        job = self.new_job(); wt, _ = self.add_worktree(job); self.commit_in(wt)
        (self.root / "jobs" / job / "handback.md").write_text("h\n"); self.ok("job.py", "set", job, "--state", "awaiting-merge")
        _, jobs = self.status(); self.assertTrue(jobs[job]["suggested"].startswith("NEEDS THE CEO"))
        self.ok("worktree.py", "merge", wt, "--title", "t", "--approved-by-ceo")
        _, jobs = self.status(); self.assertTrue(jobs[job]["suggested"].startswith("MERGED, NOT CLOSED"), jobs[job]["suggested"])

    def test_a_fresh_worktree_with_no_commits_is_not_mistaken_for_merged(self):
        job = self.new_job(); self.add_worktree(job)
        _, jobs = self.status(); self.assertFalse(jobs[job]["merged_into_default"]); self.assertTrue(jobs[job]["suggested"].startswith("NEVER STARTED"))

    def test_blocked_state(self):
        job = self.new_job(); self.ok("job.py", "set", job, "--state", "blocked")
        _, jobs = self.status(); self.assertTrue(jobs[job]["suggested"].startswith("NEEDS THE CEO"))

    def test_strays_missing_worktrees_and_orphan_job_folders(self):
        job = self.new_job(); wt, _ = self.add_worktree(job)
        self.ok("worktree.py", "add", "--repo", "my-app", "--employee", "dev", "--slug", "stray")
        (self.root / "jobs" / "20250101-ghost--x").mkdir()
        closed = self.new_job("dev", "closed-one", "none"); self.ok("job.py", "close", closed, "--outcome", "dropped", "--log", "x")
        self.git(self.proj, "worktree", "remove", "--force", str(wt))
        d, jobs = self.status()
        self.assertEqual([w["worktree"] for w in d["stray_worktrees"]], ["worktrees/my-app/dev--stray"])
        self.assertTrue(any(job in p for p in d["board_problems"])); self.assertFalse(jobs[job]["worktree_exists"])
        self.assertEqual(d["job_folders_without_row_or_close"], ["20250101-ghost--x"], "closed jobs are not orphans")
        text = self.ok("status.py")
        for needle in ("STRAY WORKTREE", "BOARD PROBLEM", "JOB FOLDER WITH NO ROW", "DOES NOT EXIST"):
            self.assertIn(needle, text)

    def test_report_ends_with_the_journal_tail(self):
        self.ok("journal.py", "add", "CEO asked: should we merge 003? options yes/no")
        d, _ = self.status(); self.assertTrue(any("should we merge 003" in l for l in d["journal_tail"]))


class StatusInsideHerdrTests(CompanyTest):
    tools = ("herdr",)
    H = {"HERDR_ENV": "1"}

    def test_live_runner_blocked_runner_gone_runner_and_live_helpers(self):
        job = self.new_job(); self.ok("job.py", "progress", job, "x")
        self.ok("job.py", "set", job, "--state", "running", "--runner", "herdr:backend-engineer (tab w1:t2)")
        def sug(agents):
            d = self.js("status.py", env=dict(self.H, FAKE_HERDR_AGENTS=json.dumps(agents)))
            self.assertEqual(d["where"], "herdr"); return d["open_jobs"][0]
        f = sug([{"name": "backend-engineer", "agent_status": "working"}])
        self.assertTrue(f["suggested"].startswith("RUNNING FINE")); self.assertTrue(f["runner_alive"])
        f = sug([{"name": "backend-engineer", "agent_status": "blocked"}])
        self.assertTrue(f["suggested"].startswith("NEEDS THE CEO"))
        f = sug([]); self.assertEqual(f["runner_status"], "gone"); self.assertFalse(f["runner_alive"])
        (self.root / "jobs" / job / "handback.md").write_text("h\n")
        f = sug([{"name": "rev-003", "agent_status": "working"}])
        self.assertTrue(f["suggested"].startswith("REVIEW RUNNING"), f["suggested"]); self.assertIn("rev-003", f["live_helpers"])


if __name__ == "__main__":
    unittest.main()

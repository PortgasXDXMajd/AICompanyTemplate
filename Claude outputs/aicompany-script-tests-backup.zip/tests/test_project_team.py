import re
import unittest

from harness import CompanyTest


class ProjectTests(CompanyTest):
    tools = ("gh",)

    def test_init_commit_register_list(self):
        out = self.ok("project.py", "init", "my-app")
        p = self.root / "projects" / "my-app"
        self.assertTrue((p / ".git").is_dir()); self.assertEqual(self.git(p, "symbolic-ref", "--short", "HEAD"), "main")
        self.fails("project.py", "commit", "my-app", needle="write these first")
        (p / "README.md").write_text("# my-app\n"); (p / "CLAUDE.md").write_text("# my-app\n")
        out = self.ok("project.py", "commit", "my-app")
        self.assertIn("gh repo create", out, "the script must hand the repo creation back so Claude Code asks the CEO")
        self.assertEqual(self.git(p, "log", "--format=%s"), "Initial commit: README and CLAUDE.md with tech stack")
        self.ok("project.py", "register", "my-app", "--repo", "acme/my-app", "--purpose", "Signup | product", "--status", "local only")
        reg = (self.root / "projects" / "README.md").read_text()
        self.assertIn("| my-app | [acme/my-app](https://github.com/acme/my-app) | Signup / product | local only |", reg)
        self.ok("project.py", "register", "my-app", "--repo", "acme/my-app", "--status", "active")
        reg = (self.root / "projects" / "README.md").read_text()
        self.assertEqual(reg.count("| my-app |"), 1, "registering again updates the row"); self.assertIn("| Signup / product | active |", reg)
        self.assertIn("my-app  [active]", self.ok("project.py", "list")); self.assertIn("local clone: yes", self.ok("project.py", "list"))
        self.assertEqual(self.git(self.root, "status", "--short", "--", "projects/my-app"), "", "product clones stay gitignored in HQ")

    def test_init_refusals(self):
        for bad in ("_hq", "My App", "UPPER", "9lives"):
            self.fails("project.py", "init", bad)
        self.ok("project.py", "init", "my-app")
        self.fails("project.py", "init", "my-app", needle="already exists")
        self.fails("project.py", "register", "my-app", "--repo", "a/b", "--status", "done", needle="status must be one of")

    def test_no_script_creates_github_repos_or_pushes(self):
        for s in (self.root / "scripts").glob("*.py"):
            src = s.read_text()
            code = "\n".join(l for l in src.splitlines() if not l.strip().startswith(("#", '"', "print", "L.die", "f\"", "\"")))
            self.assertNotRegex(code, r"\[\s*\"git\"[^\]]*\"push\"", f"{s.name} must not run git push")
            self.assertNotRegex(code, r"\"repo\",\s*\"create\"", f"{s.name} must not run gh repo create")
            self.assertNotRegex(code, r"\"pr\",\s*\"merge\"", f"{s.name} must not run gh pr merge")

    def test_clone_by_url_and_through_gh(self):
        src = self.tmp / "upstream"; src.mkdir(); self.git(src, "init", "-q", "-b", "main")
        (src / "README.md").write_text("# up\n"); self.git(src, "add", "-A"); self.git(src, "commit", "-qm", "i")
        out = self.ok("project.py", "clone", f"file://{src}", "legacy-app")
        self.assertIn("CLAUDE.md present: False", out); self.assertTrue((self.root / "projects" / "legacy-app" / "README.md").exists())
        self.fails("project.py", "clone", f"file://{src}", "legacy-app", needle="already exists")
        self.ok("project.py", "clone", "acme/Second-App", env={"FAKE_GH_REMOTE": str(src)})
        self.assertTrue((self.root / "projects" / "second-app").is_dir(), "the folder name is derived from the repo name, lower-cased")
        self.assertEqual(self.fake_calls("gh")[-1]["args"][:3], ["repo", "clone", "acme/Second-App"])


class TeamTests(CompanyTest):
    def test_add_adviser_installs_the_template_unchanged_and_is_idempotent(self):
        self.ok("team.py", "add-adviser")
        role = self.root / ".claude" / "agents" / "senior-technical-adviser.md"
        tpl = self.root / ".claude" / "skills" / "new-project" / "senior-technical-adviser.md"
        self.assertEqual(role.read_text(), tpl.read_text())
        self.assertIn("model: fable", role.read_text()); self.assertIn("effort: max", role.read_text())
        team = (self.root / "context" / "team.md").read_text()
        self.assertEqual(len(re.findall(r"^\| senior-technical-adviser \|", team, re.M)), 1)
        self.assertIn("nothing to do", self.ok("team.py", "add-adviser"))
        self.assertEqual(len(re.findall(r"^\| senior-technical-adviser \|", (self.root / "context" / "team.md").read_text(), re.M)), 1)

    def test_add_developer_keeps_engineering_rules_and_non_developer_drops_them(self):
        self.ok("team.py", "add", "backend-engineer", "--owns", "my-app backend", "--developer")
        self.ok("team.py", "add", "growth-marketer", "--owns", "`customers/`, `work/marketing/`")
        dev = (self.root / ".claude" / "agents" / "backend-engineer.md").read_text()
        mkt = (self.root / ".claude" / "agents" / "growth-marketer.md").read_text()
        self.assertIn("## Engineering rules", dev); self.assertIn('"tdd"', dev); self.assertNotIn("DEVELOPER ROLES ONLY", dev)
        self.assertNotIn("## Engineering rules", mkt); self.assertIn("## When the CEO talks to you directly", mkt)
        for text, name in ((dev, "backend-engineer"), (mkt, "growth-marketer")):
            self.assertRegex(text, rf"^---\nname: {name}\n"); self.assertIn("model: opus", text); self.assertIn("memory: project", text)
            self.assertNotIn("isolation", text.split("---")[1])

    def test_roster_row_is_added_even_when_the_commented_example_names_the_same_role(self):
        self.assertIn("| growth-marketer |", (self.root / "context" / "team.md").read_text(), "the template ships a commented example row")
        self.ok("team.py", "add", "growth-marketer", "--owns", "`work/marketing/`")
        team = (self.root / "context" / "team.md").read_text()
        live, _ = team.split("<!--", 1)
        self.assertRegex(live, r"\| growth-marketer \| Employee \| `work/marketing/` \|")
        self.assertIn("claude --agent growth-marketer", live)

    def test_add_refusals_and_list(self):
        self.ok("team.py", "add", "backend-engineer", "--owns", "x", "--developer")
        self.fails("team.py", "add", "backend-engineer", "--owns", "x", needle="already exists")
        self.fails("team.py", "add", "Bad Name", "--owns", "x", needle="kebab-case")
        self.ok("team.py", "add-adviser")
        out = self.ok("team.py", "list")
        self.assertRegex(out, r"backend-engineer\s+model=opus.*unfilled placeholders")
        self.assertRegex(out, r"senior-technical-adviser\s+model=fable effort=max\s*$|senior-technical-adviser\s+model=fable effort=max\n")
        self.assertNotIn("README", out)


if __name__ == "__main__":
    unittest.main()

import json
import unittest

from harness import CompanyTest

HERDR = {"HERDR_ENV": "1", "HERDR_WORKSPACE_ID": "w1"}


class AgentOutsideHerdrTests(CompanyTest):
    def test_where_and_refusal_outside_herdr(self):
        self.assertEqual(self.ok("agent.py", "where").strip(), "plain")
        job = self.new_job()
        for args in (["start", "--job", job, "--employee", "backend-engineer"], ["wait", "x"], ["read", "x"], ["list"], ["close", "--tab", "t"]):
            self.fails("agent.py", *args, code=3, needle="Agent tool")


class AgentTests(CompanyTest):
    tools = ("herdr",)

    def setUp(self):
        super().setUp()
        self.ok("team.py", "add", "backend-engineer", "--owns", "backend", "--developer")
        self.job = self.new_job()

    def herdr_calls(self, *prefix):
        return [c for c in self.fake_calls("herdr") if c["args"][:len(prefix)] == list(prefix)]

    def test_where_inside_herdr(self):
        self.assertEqual(self.ok("agent.py", "where", env=HERDR).strip(), "herdr")

    def test_start_employee_opens_tab_at_hq_root_starts_claude_as_that_agent_and_prompts_with_the_brief(self):
        d = self.js("agent.py", "start", "--job", self.job, "--employee", "backend-engineer", env=HERDR)
        self.assertEqual((d["agent"], d["tab"], d["pane"], d["status"]), ("backend-engineer", "w1:t7", "w1:p9", "working"))
        tab = self.herdr_calls("tab", "create")[0]["args"]
        self.assertEqual(tab[tab.index("--cwd") + 1], str(self.root), "the tab must open at the HQ root so CLAUDE.md, agents and skills load")
        self.assertIn("--no-focus", tab); self.assertEqual(tab[tab.index("--workspace") + 1], "w1")
        start = self.herdr_calls("agent", "start")[0]["args"]
        self.assertEqual(start[:7], ["agent", "start", "backend-engineer", "--kind", "claude", "--pane", "w1:p9"])
        self.assertEqual(start[start.index("--") + 1:], ["--agent", "backend-engineer", "--permission-mode", "acceptEdits"])
        prompt = self.herdr_calls("agent", "prompt")[0]["args"]
        self.assertIn(f"jobs/{self.job}/brief.md", prompt[3]); self.assertNotIn("helper subagent", prompt[3])
        self.assertEqual(prompt[4:], ["--wait", "--timeout", "20000"], "the prompt must verify that a turn started")
        r = self.row(self.job)
        self.assertEqual((r["State"], r["Runner"]), ("running", "herdr:backend-engineer (tab w1:t7)"))
        self.assertIn("started backend-engineer in Herdr tab w1:t7", self.journal())

    def test_second_run_of_the_same_employee_gets_a_unique_agent_name(self):
        env = dict(HERDR, FAKE_HERDR_AGENTS=json.dumps([{"name": "backend-engineer", "agent_status": "working"}]))
        d = self.js("agent.py", "start", "--job", self.job, "--employee", "backend-engineer", env=env)
        self.assertEqual(d["agent"], "backend-engineer-2")
        self.assertIn("herdr:backend-engineer-2", self.row(self.job)["Runner"])

    def test_start_helper_is_a_plain_session_named_by_kind_and_never_takes_the_runner_column(self):
        self.ok("job.py", "set", self.job, "--state", "handed-back", "--runner", "herdr:backend-engineer (tab w1:t2)")
        (self.root / "jobs" / self.job / "review-brief.md").write_text("# review brief\n")
        d = self.js("agent.py", "start", "--job", self.job, "--helper", "rev", env=HERDR)
        self.assertEqual(d["agent"], "rev-003"); self.assertEqual(d["brief"], f"jobs/{self.job}/review-brief.md")
        start = self.herdr_calls("agent", "start")[0]["args"]
        self.assertNotIn("--agent", start[start.index("--"):], "a helper has no role file")
        prompt = self.herdr_calls("agent", "prompt")[0]["args"][3]
        self.assertTrue(prompt.startswith("You are a helper subagent, not the Chief of Staff"))
        r = self.row(self.job)
        self.assertEqual(r["State"], "in-review"); self.assertEqual(r["Runner"], "herdr:backend-engineer (tab w1:t2)")
        self.assertIn("rev-003 running", r["Next step"])

    def test_two_helpers_are_both_named_in_next_step(self):
        for kind in ("quality", "architecture"):
            (self.root / "jobs" / self.job / f"{kind}-brief.md").write_text("b\n")
        self.ok("agent.py", "start", "--job", self.job, "--helper", "qual", env=HERDR)
        self.ok("agent.py", "start", "--job", self.job, "--helper", "arch", env=HERDR)
        nxt = self.row(self.job)["Next step"]
        self.assertIn("qual-003 running", nxt); self.assertIn("arch-003 running", nxt)

    def test_chrome_and_ask_edits_flags(self):
        (self.root / "jobs" / self.job / "qa-brief.md").write_text("b\n")
        self.ok("agent.py", "start", "--job", self.job, "--helper", "qa", "--chrome", "--ask-edits", env=HERDR)
        start = self.herdr_calls("agent", "start")[0]["args"]
        tail = start[start.index("--") + 1:]
        self.assertEqual(tail, ["--chrome"], "--ask-edits must drop acceptEdits; --chrome must be passed through")

    def test_start_refusals(self):
        self.fails("agent.py", "start", "--job", "20990101-x--y", "--employee", "backend-engineer", env=HERDR, needle="no job folder")
        self.fails("agent.py", "start", "--job", self.job, "--employee", "ghost", env=HERDR, needle="no employee")
        self.fails("agent.py", "start", "--job", self.job, "--helper", "rev", env=HERDR, needle="brief not found")
        self.assertEqual(self.herdr_calls("tab", "create"), [], "nothing may be created when the inputs are wrong")

    def test_agent_not_ready_means_the_ceo_must_look_exit_4(self):
        out = self.fails("agent.py", "start", "--job", self.job, "--employee", "backend-engineer",
                         env=dict(HERDR, FAKE_HERDR_START="not_ready"), code=4)
        self.assertIn("agent_not_ready", out); self.assertEqual(self.herdr_calls("agent", "prompt"), [], "never prompt an agent that is not ready")
        self.assertIn("the CEO must look at that tab", self.journal())

    def test_stalled_prompt_exits_5_and_warns_against_reprompting(self):
        self.fails("agent.py", "start", "--job", self.job, "--employee", "backend-engineer",
                   env=dict(HERDR, FAKE_HERDR_PROMPT="stalled"), code=5, needle="never re-prompt blind")
        self.assertEqual(len(self.herdr_calls("agent", "prompt")), 1)

    def test_wait_states(self):
        hb = self.root / "jobs" / self.job / "handback.md"
        d = json.loads(self.ok("agent.py", "--json", "wait", "backend-engineer", "--expect", hb, env=dict(HERDR, FAKE_HERDR_WAIT="timeout")))
        self.assertEqual(d["status"], "working")
        d = json.loads(self.ok("agent.py", "--json", "wait", "backend-engineer", "--expect", hb, env=dict(HERDR, FAKE_HERDR_WAIT="idle")))
        self.assertFalse(d["result_file_exists"]); self.assertIn("WITHOUT its result file", d["advice"])
        hb.write_text("# Hand-back\n\nVerdict: pass\n")
        d = json.loads(self.ok("agent.py", "--json", "wait", "backend-engineer", "--expect", hb, env=dict(HERDR, FAKE_HERDR_WAIT="done")))
        self.assertTrue(d["result_file_exists"]); self.assertEqual(d["verdict"], "pass"); self.assertIn("collect", d["advice"])
        self.fails("agent.py", "wait", "backend-engineer", env=dict(HERDR, FAKE_HERDR_WAIT="blocked"), code=4, needle="Never answer it")
        wait = self.herdr_calls("agent", "wait")[0]["args"]
        self.assertEqual(wait[3:], ["--timeout", "540000"], "stay under the 10-minute shell limit")

    def test_prompt_fix_round_points_at_the_new_brief_and_demands_a_new_result_file(self):
        fb = self.root / "jobs" / self.job / "fix-1-brief.md"; fb.write_text("fix\n")
        self.ok("agent.py", "prompt", "backend-engineer", "--brief", fb, env=HERDR)
        text = self.herdr_calls("agent", "prompt")[0]["args"][3]
        self.assertIn(f"jobs/{self.job}/fix-1-brief.md", text); self.assertIn("not the earlier one", text)
        self.fails("agent.py", "prompt", "backend-engineer", "--brief", self.root / "nope.md", env=HERDR, needle="brief not found")
        self.fails("agent.py", "prompt", "backend-engineer", "--brief", fb, env=dict(HERDR, FAKE_HERDR_PROMPT="blocked"), code=4)

    def test_read_list_close(self):
        self.assertIn("npm install", self.ok("agent.py", "read", "backend-engineer", env=HERDR))
        env = dict(HERDR, FAKE_HERDR_AGENTS=json.dumps([{"name": "rev-003", "agent_status": "working", "tab_id": "w1:t3", "pane_id": "w1:p3"}]))
        self.assertIn("rev-003  [working]  tab w1:t3", self.ok("agent.py", "list", env=env))
        self.assertIn("no live agents", self.ok("agent.py", "list", env=HERDR))
        self.ok("agent.py", "close", "--tab", "w1:t7", env=HERDR)
        self.assertEqual(self.herdr_calls("tab", "close")[0]["args"], ["tab", "close", "w1:t7"])
        self.fails("agent.py", "close", "--tab", "w1:t7", env=dict(HERDR, FAKE_HERDR_CLOSE="fail"), needle="tab close failed")

    def test_no_script_ever_sends_keys_or_answers_a_prompt(self):
        src = (self.root / "scripts" / "agent.py").read_text()
        self.assertNotIn("send-keys", src); self.assertNotIn("send_keys", src)


if __name__ == "__main__":
    unittest.main()

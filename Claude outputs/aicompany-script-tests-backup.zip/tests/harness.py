"""Test harness: a throwaway company per test, and fake command-line tools.

Nothing here touches the real repo: every test works in a temp copy, with its own git config and its own PATH.
"""
import datetime
import json
import os
import shutil
import stat
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
TODAY = datetime.datetime.now().strftime("%Y%m%d")

FAKE_TOOL = r'''#!{python}
import json, os, subprocess, sys
name = os.path.basename(sys.argv[0]); args = sys.argv[1:]
log = os.environ.get("FAKE_LOG")
if log:
    with open(log, "a") as f:
        f.write(json.dumps({{"tool": name, "args": args, "cwd": os.getcwd()}}) + "\n")
E = os.environ.get
def fail(code, msg="x"):
    sys.stderr.write(json.dumps({{"error": {{"code": code, "message": msg}}}})); sys.exit(1)
def ok(obj):
    print(json.dumps({{"result": obj}})); sys.exit(0)

if name == "herdr":
    two = " ".join(args[:2])
    if args[:1] == ["--version"]: print("herdr 9.9.9"); sys.exit(0)
    if two == "tab create": ok({{"tab": {{"tab_id": "w1:t7"}}, "root_pane": {{"pane_id": "w1:p9"}}}})
    if two == "tab close":
        if E("FAKE_HERDR_CLOSE") == "fail": fail("tab_not_found")
        ok({{}})
    if two == "agent list": ok({{"agents": json.loads(E("FAKE_HERDR_AGENTS", "[]"))}})
    if two == "agent start":
        if E("FAKE_HERDR_START") == "not_ready": fail("agent_not_ready")
        ok({{"agent": {{"name": args[2], "agent_status": "idle"}}}})
    if two == "agent prompt":
        mode = E("FAKE_HERDR_PROMPT", "timeout")
        if mode == "timeout": fail("timeout")
        if mode == "stalled": fail("agent_prompt_stalled")
        if mode == "blocked": fail("agent_blocked")
        ok({{"agent": {{"name": args[2], "agent_status": mode}}}})
    if two == "agent wait":
        mode = E("FAKE_HERDR_WAIT", "idle")
        if mode == "timeout": fail("timeout")
        ok({{"agent": {{"name": args[2], "agent_status": mode}}}})
    if two == "agent read":
        print("Do you want to run: npm install? (y/n)"); sys.exit(0)
    ok({{}})
if name == "gh":
    if args[:1] == ["--version"]: print("gh version 9.9.9"); sys.exit(0)
    if args[:2] == ["auth", "status"]: sys.exit(0 if E("FAKE_GH_AUTH", "ok") == "ok" else 1)
    if args[:2] == ["repo", "clone"]:
        if E("FAKE_GH_CLONE") == "fail": sys.exit(1)
        sys.exit(subprocess.call(["git", "clone", "-q", E("FAKE_GH_REMOTE"), args[3]]))
    sys.exit(0)
if name == "npx":
    if args[:1] == ["--version"]: print("10.0.0"); sys.exit(0)
    print("npx ran"); sys.exit(1 if E("FAKE_NPX") == "fail" else 0)
if name == "claude":
    if args[:1] == ["--version"]: print("2.9.9 (Claude Code)"); sys.exit(0)
    if args[:2] == ["mcp", "list"]: print(E("FAKE_MCP", "No MCP servers configured")); sys.exit(0)
    sys.exit(0)
if name == "maestro": print("2.6.1"); sys.exit(0)
if name == "java": sys.stderr.write('openjdk version "17.0.1"\n'); sys.exit(0)
if name == "adb":
    if args[:1] == ["devices"]:
        print("List of devices attached")
        for d in filter(None, E("FAKE_ADB_DEVICES", "").split(",")): print(d + "\tdevice")
        sys.exit(0)
    print("Android Debug Bridge version 1.0.41"); sys.exit(0)
if name == "emulator":
    if args[:1] == ["-list-avds"]: print(E("FAKE_AVDS", "")); sys.exit(0)
    if args[:1] == ["-accel-check"]: sys.exit(0 if E("FAKE_ACCEL", "ok") == "ok" else 1)
    sys.exit(0)
sys.exit(0)
'''


def _ignore(src, names):
    rel = Path(src).resolve().relative_to(REPO) if Path(src).resolve() != REPO else Path(".")
    out = {n for n in names if n in (".git", "__pycache__", ".DS_Store")}
    if rel == Path("."):
        pass
    if rel in (Path("worktrees"), Path("projects")):
        out |= {n for n in names if n != "README.md"}
    if rel == Path("jobs"):
        out |= {n for n in names if n[:2] == "20"}
    if rel == Path("context/journal"):
        out |= {n for n in names if n[:2] == "20"}
    if rel == Path(".claude/agents"):
        out |= {n for n in names if n not in ("README.md", ".gitkeep")}
    return out


class CompanyTest(unittest.TestCase):
    """Base class: self.root is a committed throwaway copy of the template."""

    tools = ()          # fake tools to put on PATH for every test of the class
    commit = True       # give HQ its first commit

    @classmethod
    def setUpClass(cls):
        cls._pristine = Path(tempfile.mkdtemp(prefix="co-pristine-"))
        shutil.copytree(REPO, cls._pristine / "hq", ignore=_ignore)
        # the template's board/log may carry real rows on a live company: start the tests from empty ones
        board = cls._pristine / "hq" / "jobs" / "BOARD.md"
        lines = board.read_text().splitlines()
        sep = next(i for i, l in enumerate(lines) if l.strip().startswith("|") and set(l.replace("|", "").strip()) <= set("-: "))
        rest = [l for l in lines[sep + 1:] if not l.strip().startswith("|")]
        board.write_text("\n".join(lines[:sep + 1] + rest) + "\n")

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls._pristine, ignore_errors=True)

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="co-test-"))
        self.root = self.tmp / "hq"
        shutil.copytree(self._pristine / "hq", self.root)
        self.bin = self.tmp / "bin"; self.bin.mkdir()
        self.fake_log = self.tmp / "fake.log"
        # The sandbox PATH holds only what the scripts may rely on, so "tool not installed" is testable on any machine.
        # Wrappers instead of symlinks: some git and python builds locate their own files from the path they were started by.
        for name, real in (("git", shutil.which("git")), ("python3", sys.executable)):
            w = self.bin / name
            w.write_text(f'#!/bin/sh\nexec "{real}" "$@"\n'); w.chmod(0o755)
        sh = shutil.which("sh")
        if sh:
            os.symlink(sh, self.bin / "sh")
        self.env = {
            "PATH": str(self.bin), "HOME": str(self.tmp), "LANG": "C", "PYTHONDONTWRITEBYTECODE": "1",
            "GIT_CONFIG_GLOBAL": os.devnull, "GIT_CONFIG_NOSYSTEM": "1",
            "GIT_AUTHOR_NAME": "t", "GIT_AUTHOR_EMAIL": "t@t", "GIT_COMMITTER_NAME": "t", "GIT_COMMITTER_EMAIL": "t@t",
            "FAKE_LOG": str(self.fake_log),
        }
        for t in self.tools:
            self.fake(t)
        if self.commit:
            self.git(self.root, "init", "-q", "-b", "main")
            self.git(self.root, "add", "-A")
            self.git(self.root, "commit", "-qm", "Initial commit")

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    # ------------------------------------------------------------ helpers
    def fake(self, name):
        p = self.bin / name
        p.write_text(FAKE_TOOL.format(python=sys.executable))
        p.chmod(p.stat().st_mode | stat.S_IEXEC)

    def git(self, cwd, *args, check=True):
        p = subprocess.run(["git", "-C", str(cwd), *args], env=self.env, text=True, capture_output=True)
        if check and p.returncode != 0:
            self.fail(f"git {' '.join(args)} failed: {p.stderr}")
        return p.stdout.strip()

    def run_script(self, script, *args, env=None, cwd=None):
        e = dict(self.env); e.update(env or {})
        p = subprocess.run([sys.executable, str(self.root / "scripts" / script), *map(str, args)],
                           env=e, cwd=str(cwd or self.root), text=True, capture_output=True)
        return p.returncode, p.stdout, p.stderr

    def ok(self, script, *args, env=None, cwd=None):
        code, out, err = self.run_script(script, *args, env=env, cwd=cwd)
        self.assertEqual(code, 0, f"{script} {' '.join(map(str, args))} exited {code}\nSTDOUT:\n{out}\nSTDERR:\n{err}")
        return out

    def fails(self, script, *args, env=None, code=1, needle=None):
        c, out, err = self.run_script(script, *args, env=env)
        self.assertEqual(c, code, f"{script} {' '.join(map(str, args))}: expected exit {code}, got {c}\n{out}\n{err}")
        if needle:
            self.assertIn(needle.lower(), (out + err).lower())
        return out + err

    def js(self, script, *args, env=None):
        return json.loads(self.ok(script, "--json", *args, env=env))

    def board(self):
        rows = []
        for l in (self.root / "jobs" / "BOARD.md").read_text().splitlines():
            if l.startswith("| 20"):
                c = [x.strip() for x in l.strip().strip("|").split("|")]
                rows.append(dict(zip(["Job", "Employee", "Task", "Repo", "Worktree", "Branch", "Base", "Runner", "State", "Updated", "Next step"], c)))
        return rows

    def row(self, job):
        return next(r for r in self.board() if r["Job"] == job)

    def journal(self):
        files = sorted((self.root / "context" / "journal").glob("20*.md"))
        return files[-1].read_text() if files else ""

    def fake_calls(self, tool=None):
        if not self.fake_log.exists():
            return []
        calls = [json.loads(l) for l in self.fake_log.read_text().splitlines()]
        return [c for c in calls if tool is None or c["tool"] == tool]

    def make_project(self, name="my-app"):
        p = self.root / "projects" / name
        p.mkdir(parents=True)
        self.git(p, "init", "-q", "-b", "main")
        (p / "README.md").write_text(f"# {name}\n"); (p / "CLAUDE.md").write_text(f"# {name}\n\n## Tech stack\n")
        (p / "app.py").write_text("def signup():\n    return 1\n")
        self.git(p, "add", "-A"); self.git(p, "commit", "-qm", "init")
        return p

    def new_job(self, employee="backend-engineer", slug="003-email-signup", repo="my-app", task="Plan 003: email signup"):
        self.ok("job.py", "new", "--employee", employee, "--slug", slug, "--task", task, "--repo", repo)
        return f"{TODAY}-{employee}--{slug}"

    def add_worktree(self, job, employee="backend-engineer", slug="003-email-signup", repo="my-app"):
        d = self.js("worktree.py", "add", "--repo", repo, "--employee", employee, "--slug", slug, "--job", job)
        return self.root / d["worktree"], d

    def commit_in(self, wt, fname="feature.py", content="x = 1\n", msg="work"):
        (Path(wt) / fname).write_text(content)
        self.git(wt, "add", fname); self.git(wt, "commit", "-qm", msg)

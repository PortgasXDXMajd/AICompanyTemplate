import datetime
import unittest

from harness import CompanyTest, TODAY


class JobTests(CompanyTest):
    def test_new_creates_folder_brief_progress_row_and_journal(self):
        d = self.js("job.py", "new", "--employee", "backend-engineer", "--slug", "003-email-signup",
                    "--task", "Plan 003: email signup", "--repo", "my-app")
        job = f"{TODAY}-backend-engineer--003-email-signup"
        self.assertEqual(d["job"], job); self.assertEqual(d["state"], "briefed")
        folder = self.root / "jobs" / job
        brief = (folder / "brief.md").read_text()
        self.assertIn(str(folder), brief, "the brief must name the absolute job folder at the HQ root")
        self.assertIn("Plan 003: email signup", brief)
        for heading in ("**From**", "**Goal**", "**Worktree**", "**Read first**", "**Definition of done**",
                        "**Constraints**", "**Progress**", "**Return**"):
            self.assertIn(heading, brief)
        self.assertTrue((folder / "progress.md").exists())
        r = self.row(job)
        self.assertEqual((r["Employee"], r["Repo"], r["State"]), ("backend-engineer", "my-app", "briefed"))
        self.assertIn("job created", self.journal()); self.assertIn(job, self.journal())

    def test_new_refuses_duplicates_and_bad_names(self):
        self.new_job()
        self.fails("job.py", "new", "--employee", "backend-engineer", "--slug", "003-email-signup", "--task", "again", needle="already exists")
        self.fails("job.py", "new", "--employee", "Backend Engineer", "--slug", "x", "--task", "t", needle="kebab-case")
        self.fails("job.py", "new", "--employee", "dev", "--slug", "Bad Slug", "--task", "t", needle="slug")
        self.assertEqual(len(self.board()), 1)

    def test_slug_may_start_with_a_digit(self):
        self.new_job(slug="007-x")

    def test_pipes_and_newlines_in_task_do_not_break_the_table(self):
        self.ok("job.py", "new", "--employee", "dev", "--slug", "a", "--task", "fix a | b\nand c")
        r = self.row(f"{TODAY}-dev--a")
        self.assertEqual(r["Task"], "fix a / b and c")
        self.assertEqual(r["State"], "briefed")

    def test_board_header_and_trailing_comment_survive_writes(self):
        before = (self.root / "jobs" / "BOARD.md").read_text()
        job = self.new_job(); self.ok("job.py", "set", job, "--state", "running"); self.ok("job.py", "close", job, "--outcome", "dropped", "--log", "x")
        after = (self.root / "jobs" / "BOARD.md").read_text()
        self.assertEqual(before.strip(), after.strip())

    def test_set_state_runner_next_and_default_next_step(self):
        job = self.new_job()
        self.ok("job.py", "set", job, "--state", "running", "--runner", "subagent")
        r = self.row(job)
        self.assertEqual((r["State"], r["Runner"]), ("running", "subagent"))
        self.assertIn("hand-back", r["Next step"])
        self.ok("job.py", "set", job, "--state", "in-review", "--next", "rev-003 running")
        self.assertEqual(self.row(job)["Next step"], "rev-003 running")
        self.ok("job.py", "set", job, "--state", "awaiting-merge")
        self.assertIn("merge", self.row(job)["Next step"])
        self.assertIn("state=awaiting-merge", self.journal())

    def test_set_rejects_unknown_state_unknown_job_and_empty_call(self):
        job = self.new_job()
        self.fails("job.py", "set", job, "--state", "done", needle="state must be one of")
        self.fails("job.py", "set", "20990101-x--y", "--state", "running", needle="no open job")
        self.fails("job.py", "set", job, needle="nothing to set")

    def test_every_documented_state_is_accepted(self):
        job = self.new_job()
        readme = (self.root / "jobs" / "README.md").read_text()
        for state in ("briefed", "running", "blocked", "handed-back", "in-review", "fixing", "awaiting-merge", "interrupted", "failed"):
            self.assertIn(f"`{state}`", readme, f"jobs/README.md does not document {state}")
            self.ok("job.py", "set", job, "--state", state)

    def test_progress_appends_timestamped_lines(self):
        job = self.new_job()
        self.ok("job.py", "progress", job, "start: step 1 failing test")
        self.ok("job.py", "progress", job, "done: step 1 | red then green")
        lines = [l for l in (self.root / "jobs" / job / "progress.md").read_text().splitlines() if l.startswith("- ")]
        self.assertEqual(len(lines), 2)
        self.assertRegex(lines[0], r"^- \d{4}-\d\d-\d\d \d\d:\d\d start: step 1")
        self.fails("job.py", "progress", "20990101-x--y", "hi", needle="no job folder")

    def test_show_reports_files_verdicts_and_progress(self):
        job = self.new_job(); d = self.root / "jobs" / job
        (d / "review.md").write_text("# Review\nok\n\nVerdict: pass with fixes\n")
        (d / "quality.md").write_text("# Quality\ncut off mid-sen")
        (d / "review-brief.md").write_text("brief, not a verdict file\n")
        self.ok("job.py", "progress", job, "step 1")
        s = self.js("job.py", "show", job)
        self.assertEqual(s["verdicts"]["review.md"], "pass with fixes")
        self.assertIsNone(s["verdicts"]["quality.md"])
        self.assertIn("review.md", s["files"]); self.assertNotIn("review-brief.md", s["verdicts"])
        self.assertTrue(any("step 1" in l for l in s["progress_tail"]))
        text = self.ok("job.py", "show", job)
        self.assertIn("NO VERDICT LINE", text)

    def test_list_text_and_json(self):
        self.assertIn("no open jobs", self.ok("job.py", "list"))
        job = self.new_job()
        self.assertIn(job, self.ok("job.py", "list"))
        self.assertEqual(self.js("job.py", "list")["open_jobs"][0]["Job"], job)

    def test_close_merged_logs_and_removes_row(self):
        job = self.new_job()
        self.ok("job.py", "close", job, "--outcome", "merged", "--log", "Email signup API shipped", "--path", "specs/003-email-signup.md")
        self.assertEqual(self.board(), [])
        log = (self.root / "context" / "log.md").read_text().splitlines()[-1]
        self.assertRegex(log, r"^\d{4}-\d\d-\d\d \| backend-engineer \| Email signup API shipped \| specs/003-email-signup.md$")
        closed = (self.root / "jobs" / job / "closed.md").read_text()
        self.assertIn("outcome: merged", closed)
        self.assertTrue((self.root / "jobs" / job / "brief.md").exists(), "the job folder stays as the record")
        self.fails("job.py", "close", job, "--outcome", "merged", "--log", "again", needle="no open job")

    def test_close_dropped_does_not_touch_the_work_log(self):
        before = (self.root / "context" / "log.md").read_text()
        job = self.new_job()
        self.ok("job.py", "close", job, "--outcome", "dropped", "--log", "CEO changed direction")
        self.assertEqual(before, (self.root / "context" / "log.md").read_text())
        self.assertIn("outcome: dropped", (self.root / "jobs" / job / "closed.md").read_text())

    def test_scripts_run_from_an_hq_worktree_copy_still_write_to_the_real_hq_root(self):
        job = self.new_job(employee="senior-technical-adviser", slug="spec-001", repo="_hq")
        wt, _ = self.add_worktree(job, "senior-technical-adviser", "spec-001", "_hq")
        copy = wt / "scripts" / "job.py"
        self.assertTrue(copy.exists(), "an HQ worktree carries its own copy of scripts/")
        import subprocess, sys
        p = subprocess.run([sys.executable, str(copy), "progress", job, "written from the worktree copy"],
                           env=self.env, cwd=str(wt), text=True, capture_output=True)
        self.assertEqual(p.returncode, 0, p.stderr)
        self.assertIn("written from the worktree copy", (self.root / "jobs" / job / "progress.md").read_text())
        self.assertFalse((wt / "jobs" / job).exists(), "nothing may be written into the stale copy inside the worktree")


class JournalTests(CompanyTest):
    def test_add_creates_todays_file_with_time_and_job(self):
        out = self.ok("journal.py", "add", "CEO asked for | email signup", "--job", "20260101-x--y")
        self.assertRegex(out.strip(), r"^- \d\d:\d\d CEO asked for / email signup \(20260101-x--y\)$")
        f = self.root / "context" / "journal" / (datetime.datetime.now().strftime("%Y-%m-%d") + ".md")
        self.assertTrue(f.read_text().startswith("# Journal "))

    def test_tail_with_and_without_a_journal(self):
        self.assertIn("no journal yet", self.ok("journal.py", "tail"))
        for i in range(5):
            self.ok("journal.py", "add", f"entry {i}")
        out = self.ok("journal.py", "tail", "-n", "2")
        self.assertIn("entry 4", out); self.assertNotIn("entry 1", out)

    def test_unclosed_lists_days_since_the_last_summary_and_close_marks_the_day(self):
        jd = self.root / "context" / "journal"
        (jd / "2026-01-01.md").write_text("# Journal\n- 09:00 a\n\n## Day summary\n\nfine\n")
        (jd / "2026-01-02.md").write_text("# Journal\n- 09:00 never closed\n")
        self.ok("journal.py", "add", "today")
        out = self.ok("journal.py", "unclosed")
        self.assertIn("2026-01-02.md", out); self.assertNotIn("2026-01-01.md", out)
        self.ok("journal.py", "close", "Done: a. Open: b. First thing tomorrow: c.")
        self.assertIn("## Day summary", self.journal()); self.assertIn("First thing tomorrow: c.", self.journal())
        self.assertIn("every journal file ends in a day summary", self.ok("journal.py", "unclosed"))


if __name__ == "__main__":
    unittest.main()
